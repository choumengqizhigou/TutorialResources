﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace WPF_LoginUI
{
    public class LoginVM : INotifyPropertyChanged
    {
        private MainWindow _main;
        public LoginVM( MainWindow main)
        {
            _main = main;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }

        private LoginModel _LoginM = new LoginModel();



        public string UserName
        {
            get { return _LoginM.UserName; }
            set
            {
                _LoginM.UserName = value;
                RaisePropertyChanged("UserName");
            }
        }

        public string Password
        {
            get { return _LoginM.Password; }
            set
            {
                _LoginM.Password = value;
                RaisePropertyChanged("Password");
            }
        }


        /// <summary>
        /// 登录方法
        /// </summary>
        void LoginFunc()
        {
            MessageBox.Show(Password);
            return;

            if (UserName == "wpf" && Password == "666")
            {
                //弹出新的界面 Ctrl+k Ctrl+D
                //MessageBox.Show("OK");
                Index index = new Index();
                index.Show();

                //想办法把当前打开的界面的实例给他拿到， main
                //this.Hide();
                _main.Hide();
            }
            else
            {
                //弹出一个警告框
                MessageBox.Show("输入的用户名或密码不正确");

                UserName = "";
                Password = "";
            }
        }

        bool CanLoginExecute()
        {
            return true;
        }


        // 命令 等下绑定登录按钮上
        public ICommand LoginAction
        {
            get
            {
                return new RelayCommond(LoginFunc, CanLoginExecute);
            }
        }


    }
}
