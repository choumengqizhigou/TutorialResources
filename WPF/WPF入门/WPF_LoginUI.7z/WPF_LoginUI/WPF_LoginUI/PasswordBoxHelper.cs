﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace WPF_LoginUI
{
    public class PasswordBoxHelper
    {
        //ALT ENTER
        public static string GetMyPasword(DependencyObject obj)
        {
            return (string)obj.GetValue(MyPaswordProperty);
        }

        public static void SetMyPasword(DependencyObject obj, string value)
        {
            obj.SetValue(MyPaswordProperty, value);
        }

        // Using a DependencyProperty as the backing store for MyPasword.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MyPaswordProperty =
            DependencyProperty.RegisterAttached("MyPasword", typeof(string), typeof(PasswordBoxHelper));





        public static bool GetIsEnableBind(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsEnableBindProperty);
        }

        public static void SetIsEnableBind(DependencyObject obj, bool value)
        {
            obj.SetValue(IsEnableBindProperty, value);
        }

        // Using a DependencyProperty as the backing store for IsEnableBind.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsEnableBindProperty =
            DependencyProperty.RegisterAttached("IsEnableBind", typeof(bool), typeof(PasswordBoxHelper), new PropertyMetadata(true, OnPasswordPropertyChanged));

        private static void OnPasswordPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            PasswordBox pwd = d as PasswordBox;
            if (pwd == null)
                return;

            if ((bool)e.OldValue)
                pwd.PasswordChanged -= OnPwdProChaned;

            if ((bool)e.NewValue)
                pwd.PasswordChanged += OnPwdProChaned;
        }

        private static void OnPwdProChaned(object sender, RoutedEventArgs e)
        {
            PasswordBox pwd = sender as PasswordBox;

            SetMyPasword(pwd, pwd.Password);


        }
    }
}
