﻿using MaanshanTeachersCollege.ControlsUC;
using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Pages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.Expando;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MaanshanTeachersCollege
{
	public partial class LoginForm : Form
	{
		public LoginForm()
		{
			InitializeComponent();


			// 固定大小
			//this.Width = 1366;
			//this.Height = 768;
			//this.FormBorderStyle = FormBorderStyle.FixedSingle;
			this.StartPosition = FormStartPosition.CenterScreen;
			//this.MaximizeBox = false;
		}

		private void btnLogin_Click(object sender, EventArgs e)
		{
			string userName = txtUserName.Text.Trim();
			string pwd = txtPassword.Text.Trim();

			UserModel userModel = new UserModel();

			if (userName == "丑萌气质狗" && pwd == "666")
			{
				List<MenuModel>  lstMenuItems = new List<MenuModel>();
				lstMenuItems.Add(new MenuModel() { MenuIcon = "home", MenuName = "Home", MenuText = "首页" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "selection", MenuName = "CourseSelection", MenuText = "选课" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "grade", MenuName = "GradeQuery", MenuText = "成绩查询" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "course", MenuName = "CourseManagement", MenuText = "课程管理" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "personnel", MenuName = "PersonnelManagement", MenuText = "人员管理" });
				lstMenuItems.Add(new MenuModel()
				{
					MenuIcon = "permissions",
					MenuName = "PermissionOperate",
					MenuText = "权限",
					SubMenu = new List<MenuModel>()
						{
							new MenuModel()
							{
								MenuIcon="circle",
								MenuName="RoleManagerment",
								MenuText = "角色管理"
							},
							new MenuModel()
							{
								MenuIcon="circle",
								MenuName="PermissionConf",
								MenuText = "权限配置"
							}
						}
				});
				lstMenuItems.Add(new MenuModel() { MenuIcon = "setting", MenuName = "Setting", MenuText = "设置" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "about", MenuName = "About", MenuText = "关于" });

				userModel.MenuItems = lstMenuItems;
			}
			else if (userName == "winform" && pwd == "666")
			{
				List<MenuModel> lstMenuItems = new List<MenuModel>();
				lstMenuItems.Add(new MenuModel() { MenuIcon = "home", MenuName = "Home", MenuText = "首页" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "selection", MenuName = "CourseSelection", MenuText = "选课" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "grade", MenuName = "GradeQuery", MenuText = "成绩查询" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "course", MenuName = "CourseManagement", MenuText = "课程管理" });
				//lstMenuItems.Add(new MenuModel() { MenuIcon = "personnel", MenuName = "PersonnelManagement", MenuText = "人员管理" });
				//lstMenuItems.Add(new MenuModel()
				//{
				//	MenuIcon = "permissions",
				//	MenuName = "PermissionOperate",
				//	MenuText = "权限",
				//	SubMenu = new List<MenuModel>()
				//		{
				//			new MenuModel()
				//			{
				//				MenuIcon="circle",
				//				MenuName="RoleManagerment",
				//				MenuText = "角色管理"
				//			},
				//			new MenuModel()
				//			{
				//				MenuIcon="circle",
				//				MenuName="PermissionConf",
				//				MenuText = "权限配置"
				//			}
				//		}
				//});
				lstMenuItems.Add(new MenuModel() { MenuIcon = "setting", MenuName = "Setting", MenuText = "设置" });
				lstMenuItems.Add(new MenuModel() { MenuIcon = "about", MenuName = "About", MenuText = "关于" });

				userModel.MenuItems = lstMenuItems;
			}
			else
			{
				MessageBox.Show("用户名或者密码不正确");
				return;
			}

			userModel.UserName = userName;
			userModel.Password = pwd;


			MyGlobalSingleton.Instance.CurrentLoginUser = userModel;

			this.DialogResult = DialogResult.OK;
			this.Close();
		}
	}
}
