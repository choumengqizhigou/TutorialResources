﻿using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaanshanTeachersCollege
{
	public sealed class MyGlobalSingleton
	{
		// 使用 Lazy<T> 确保线程安全并延迟初始化
		private static readonly Lazy<MyGlobalSingleton> lazyInstance =
			new Lazy<MyGlobalSingleton>(() => new MyGlobalSingleton());

		// 公共访问点
		public static MyGlobalSingleton Instance => lazyInstance.Value;

		// 私有构造函数，防止外部实例化
		private MyGlobalSingleton()
		{
			// 初始化代码放这里
		}

		//private List<MenuModel> _menuItems;

		//public List<MenuModel> MenuItems
		//{
		//	get
		//	{
		//		if (_menuItems == null)
		//		{
		//			_menuItems = new List<MenuModel>();
		//			_menuItems.Add(new MenuModel() { MenuIcon = "home", MenuName = "Home", MenuText = "首页" });
		//			_menuItems.Add(new MenuModel() { MenuIcon = "selection", MenuName = "CourseSelection", MenuText = "选课" });
		//			_menuItems.Add(new MenuModel() { MenuIcon = "grade", MenuName = "GradeQuery", MenuText = "成绩查询" });
		//			_menuItems.Add(new MenuModel() { MenuIcon = "course", MenuName = "CourseManagement", MenuText = "课程管理" });
		//			_menuItems.Add(new MenuModel() { MenuIcon = "personnel", MenuName = "PersonnelManagement", MenuText = "人员管理" });
		//			_menuItems.Add(new MenuModel()
		//			{
		//				MenuIcon = "permissions",
		//				MenuName = "PermissionOperate",
		//				MenuText = "权限",
		//				SubMenu = new List<MenuModel>()
		//				{
		//					new MenuModel()
		//					{
		//						MenuIcon="circle",
		//						MenuName="RoleManagerment",
		//						MenuText = "角色管理"
		//					},
		//					new MenuModel()
		//					{
		//						MenuIcon="circle",
		//						MenuName="PermissionConf",
		//						MenuText = "权限配置"
		//					}
		//				}
		//			});
		//			_menuItems.Add(new MenuModel() { MenuIcon = "setting", MenuName = "Setting", MenuText = "设置" });
		//			_menuItems.Add(new MenuModel() { MenuIcon = "about", MenuName = "About", MenuText = "关于" });
		//		}
		//		return _menuItems;
		//	}
		//	set { _menuItems = value; }
		//}

		private List<RoleModel> _lstRole;
		/// <summary>
		/// 角色列表
		/// </summary>
		public List<RoleModel> LstRole
		{
			get
			{
				if (_lstRole == null)
				{
					_lstRole=new List<RoleModel>();
					//加载数据
					_lstRole.Add(new RoleModel
					{
						RoleID = "1",
						RoleName = "学生",
					});

					_lstRole.Add(new RoleModel
					{
						RoleID = "2",
						RoleName = "教师",
					});

					_lstRole.Add(new RoleModel
					{
						RoleID = "3",
						RoleName = "辅导员",
					});

					_lstRole.Add(new RoleModel
					{
						RoleID = "4",
						RoleName = "管理员",
					});
				}
				return _lstRole;
			}
			set { _lstRole = value; }
		}

		List<RoleModel> lstRole { get; set; } = new List<RoleModel>();

		public MainForm CurrentMainForm { get; set; }

		/// <summary>
		/// 当前登录的用户信息
		/// </summary>
		public UserModel CurrentLoginUser { get; set; }

		/// <summary>
		/// 加载界面
		/// </summary>
		public void LoadPageUC(string menuName, string menuText)
		{
			UserControl uc = null;
			switch (menuName)
			{
				case "Home":
					uc = new HomePageUC();
					break;
				case "CourseSelection":
					uc = new CourseSelectionPageUC();
					break;
				case "CourseManagement":
					uc = new CourseManagementPageUC();
					break;
				case "PersonnelManagement":
					uc = new PersonnelManagementPageUC();
					break;
				case "RoleManagerment":
					uc = new RoleManagermentPageUC();
					break;
				case "PermissionConf":
					uc = new PermissionConfPageUC();
					break;
				case "Settings":
					uc = new SettingPageUC();
					break;
				case "About":
					uc = new AboutPageUC();
					break;
				default:
					uc = new NotFoundPageUC(menuText);
					break;
			}

			CurrentMainForm.PanelContentView.Controls.Clear();
			uc.Dock = DockStyle.Fill;
			CurrentMainForm.PanelContentView.Controls.Add(uc);
		}
	}
}
