﻿using MaanshanTeachersCollege.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaanshanTeachersCollege.Models
{
	public class PersonnelModel
	{
		/// <summary>
		/// 学号
		/// </summary>
		public string ID { get; set; }
		/// <summary>
		/// 姓名
		/// </summary>
		public string Name { get; set; }
		/// <summary>
		/// 性别
		/// </summary>
		public GenderEnum Gender { get; set; }
		/// <summary>
		/// 身份证号
		/// </summary>
		public string IDNumber { get; set; }
		/// <summary>
		/// 家庭住址
		/// </summary>
		public string Address { get; set; }
	}
}
