﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaanshanTeachersCollege.Models
{
	public class MenuModel
	{
		/// <summary>
		/// 菜单图片
		/// </summary>
        public string MenuIcon { get; set; }
		/// <summary>
		/// 菜单名称
		/// </summary>
		public string MenuName { get; set; }
		/// <summary>
		/// 菜单显示文本
		/// </summary>
		public string MenuText { get; set; }
		/// <summary>
		/// 子菜单
		/// </summary>
		public List<MenuModel> SubMenu { get; set; }
	}
}
