﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaanshanTeachersCollege.Models
{
	public class MenuPermissionModel
	{
		/// <summary>
		/// 菜单ID
		/// </summary>
		public string MenuID { get; set; }
		/// <summary>
		/// 菜单名称
		/// </summary>
		public string PMenuName { get; set; }
		/// <summary>
		/// 子菜单名称
		/// </summary>
		public string SMenuName { get; set; }
		/// <summary>
		/// 增
		/// </summary>
		public bool IsAdd { get; set; }
		/// <summary>
		/// 删
		/// </summary>
		public bool IsDelete { get; set; }
		/// <summary>
		/// 改
		/// </summary>
		public bool IsModify { get; set; }
		/// <summary>
		/// 查
		/// </summary>
		public bool IsCheck { get; set; }
	}
}
