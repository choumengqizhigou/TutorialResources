﻿using MaanshanTeachersCollege.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaanshanTeachersCollege.Models
{
	public class CourseModel
	{
		/// <summary>
		/// 课程号
		/// </summary>
		public string CourseID { get; set; }
		/// <summary>
		/// 课程名称
		/// </summary>
		public string CourseName { get; set; }
		/// <summary>
		/// 授课老师
		/// </summary>
		public string CourseTeacher { get; set; }
		/// <summary>
		/// 授课教室
		/// </summary>
		public string CourseClassroom { get; set; }
		/// <summary>
		/// 课程目的
		/// </summary>
		public string CourseObjectives { get; set; }
	}
}
