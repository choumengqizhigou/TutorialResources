﻿using MaanshanTeachersCollege.ControlsUC;
using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Pages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices.Expando;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MaanshanTeachersCollege
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();

			//保留当前界面实例，方便在全局单例中随时调用
			MyGlobalSingleton.Instance.CurrentMainForm = this;

			// 固定大小
			this.Width = 1366;
			this.Height = 768;
			//this.FormBorderStyle = FormBorderStyle.FixedSingle;
			this.StartPosition = FormStartPosition.CenterScreen;
			//this.MaximizeBox = false;

			this.MinimumSize = new Size(800, 600);

			label1.Text = DateTime.Now.ToString("yyyy-MM-dd");

			LoadMenu();

			MenuModel model = MyGlobalSingleton.Instance.CurrentLoginUser.MenuItems.First();

			MyGlobalSingleton.Instance.LoadPageUC(model.MenuName, model.MenuText);
		}

		/// <summary>
		/// 主界面承载内容的Panel
		/// </summary>
		public Panel PanelContentView
		{
			get
			{
				return this.panelView;
			}
		}

		public void LoadMenu()
		{
			foreach (var item in MyGlobalSingleton.Instance.CurrentLoginUser.MenuItems)
			{
				if (item.SubMenu == null)
				{
					MenuItemUC menuItemUC = new MenuItemUC(item.MenuIcon, item.MenuText);
					menuItemUC.Clicked += (s, e) =>
					{
						// 这里写跳转界面的逻辑，比如
						MyGlobalSingleton.Instance.LoadPageUC(item.MenuName, item.MenuText);
					};
					flowLayoutPanel1.Controls.Add(menuItemUC);
				}
				else
				{

					MenuUC menuUC = new MenuUC(item);

					flowLayoutPanel1.Controls.Add(menuUC);
				}
			}
		}

		//默认是展开的
		public bool IsExpand = true;

		private void button4_Click(object sender, EventArgs e)
		{
			if (timerExpand.Enabled)
				return;
			timerExpand.Start();
		}

		private void timerExpand_Tick(object sender, EventArgs e)
		{
			if (IsExpand)
			{
				tableLayoutPanel2.ColumnStyles[0].Width -= 10;
				if (tableLayoutPanel2.ColumnStyles[0].Width <= 70)
				{
					tableLayoutPanel2.ColumnStyles[0].Width = 70;
					IsExpand = false;
					timerExpand.Stop();
				}
			}
			else
			{
				tableLayoutPanel2.ColumnStyles[0].Width += 10;
				if (tableLayoutPanel2.ColumnStyles[0].Width >= 240)
				{
					tableLayoutPanel2.ColumnStyles[0].Width = 240;

					IsExpand = true;
					timerExpand.Stop();
				}
			}
		}
	}
}
