﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaanshanTeachersCollege.Enums
{
	public enum GenderEnum
	{
		男 = 1,
		女
	}
}
