﻿using MaanshanTeachersCollege.ControlsUC;
using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Pages;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.Expando;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MaanshanTeachersCollege
{


	public partial class CourseSelectionForm : Form
	{
		private int pageSize = 10; // 每页显示数量
		private int currentPage = 1; // 当前页
		private int totalPage = 0; // 总页数

		List<CourseModel> lstCourse { get; set; } = new List<CourseModel>();

		public void BeautifyDataGridView(DataGridView dgv)
		{
			dgv.AutoGenerateColumns = false;
			dgv.RowHeadersVisible = false;

			dgv.EnableHeadersVisualStyles = false;
			dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(46, 87, 162);
			dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
			dgv.ColumnHeadersDefaultCellStyle.Font = new Font("微软雅黑", 10, FontStyle.Bold);
			dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			dgv.ColumnHeadersHeight = 40; // 可根据需要调整高度

			dgv.DefaultCellStyle.BackColor = Color.White;
			dgv.DefaultCellStyle.ForeColor = Color.Black;
			dgv.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
			dgv.DefaultCellStyle.SelectionForeColor = Color.Black;
			dgv.DefaultCellStyle.Font = new Font("微软雅黑", 10);
			dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);

			dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			dgv.RowTemplate.Height = 30;
			dgv.BorderStyle = System.Windows.Forms.BorderStyle.None;
			dgv.GridColor = Color.LightGray;

			dgv.AllowUserToAddRows = false;
			dgv.AllowUserToDeleteRows = false;
			dgv.AllowUserToResizeRows = false;
			dgv.ReadOnly = true;
			dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		}


		Color hoverColor = Color.LightSkyBlue;
		Color normalColor = Color.White;

		private int lastRowIndex = -1;

		/// <summary>
		/// 选课页面被点击的button
		/// </summary>
		public Button BtnCurrentClick { get; set; }

		public CourseSelectionForm(Button btn)
		{
			InitializeComponent();

			BtnCurrentClick = btn;

			//this.FormBorderStyle = FormBorderStyle.FixedSingle;
			this.StartPosition = FormStartPosition.CenterParent;
			//this.MaximizeBox = false;

			////调整grid样式 列铺满
			//gridPerson.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			////列标题居中
			//gridPerson.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			//单元格内容居中
			foreach (DataGridViewColumn item in this.gridCourse.Columns)
			{
				item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				item.SortMode = DataGridViewColumnSortMode.NotSortable;//列标题右边有预留一个排序小箭头的位置，所以整个列标题就向左边多一点，而当把SortMode属性设置为NotSortable时，不使用排序，也就没有那个预留的位置，所有完全居中了
			}
			////选择整行
			//gridPerson.SelectionMode= DataGridViewSelectionMode.FullRowSelect;
			//不允许多选
			BeautifyDataGridView(gridCourse);

			gridCourse.CellDoubleClick += GridCourse_CellDoubleClick; ;
			gridCourse.CellMouseEnter += dataGridView1_CellMouseEnter;
			gridCourse.CellMouseLeave += dataGridView1_CellMouseLeave;

			gridCourse.MultiSelect = false;

			//gridPerson.EditMode = DataGridViewEditMode.EditOnEnter;

			//加载数据
			lstCourse.Add(new CourseModel
			{
				CourseID = "1",
				CourseName = "高等数学",
				CourseClassroom = "5-11",
				CourseTeacher = "丑萌气质狗",
				CourseObjectives = "就你也配教高等数学，误人子弟无疑！"
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "2",
				CourseName = "C语言基础",
				CourseClassroom = "10-10",
				CourseTeacher = "DeepSeek",
				CourseObjectives = "这课自己预习、复习、提前会发答案！"
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "3",
				CourseName = "思想政治",
				CourseClassroom = "3-3",
				CourseTeacher = "豆包",
				CourseObjectives = "讲给能懂的人听，人民万岁！"
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "4",
				CourseName = "WPF图书馆程序开发",
				CourseClassroom = "3-3",
				CourseTeacher = "ChatGPT",
				CourseObjectives = "别指望旷课，每节课都点名，亲自点！"
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "5",
				CourseName = "操作系统",
				CourseClassroom = "4-4",
				CourseTeacher = "别看了，王杰",
				CourseObjectives = "这节课很有意思，课上可以玩消消乐！"
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "6",
				CourseName = "x86汇编基础讲解",
				CourseClassroom = "6-6",
				CourseTeacher = "还有你周飞",
				CourseObjectives = "你就说x86 6不6吧！"
			});


			lstCourse.Add(new CourseModel
			{
				CourseID = "7",
				CourseName = "SQLServer数据库案例",
				CourseClassroom = "6-5",
				CourseTeacher = "张伟就是我",
				CourseObjectives = "这节课真的由张伟授课哦..."
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "8",
				CourseName = "图形学",
				CourseClassroom = "2-3",
				CourseTeacher = "偷偷毕业-李明博",
				CourseObjectives = "有意思的，快来！"
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "9",
				CourseName = "毕业设计",
				CourseClassroom = "2-1",
				CourseTeacher = "刘成成",
				CourseObjectives = "就你TM上学这样子，还想毕业？！"
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "10",
				CourseName = "就业指导",
				CourseClassroom = "0-0",
				CourseTeacher = "周晓晓",
				CourseObjectives = "听听总没有坏处。"
			});

			lstCourse.Add(new CourseModel
			{
				CourseID = "11",
				CourseName = "回到过去",
				CourseClassroom = "-1.-1",
				CourseTeacher = "曾经的你",
				CourseObjectives = "欲买桂花同载酒，终不似，少年游。"
			});

			//var multiSelectColumn = new DataGridViewMultiSelectColumn()
			//{
			//	HeaderText = "多选列",
			//	Name = "multiSelectColumn",
			//	DataPropertyName = "Tags" // 对应你的数据模型中的 string 字段
			//};

			//gridPerson.Columns.Add(multiSelectColumn);


			//var genderSource = new List<KeyValuePair<GenderEnum, string>>()
			//{
			//	new KeyValuePair<GenderEnum, string>(GenderEnum.男, "男"),
			//	new KeyValuePair<GenderEnum, string>(GenderEnum.女, "女")
			//};

			//// 设置下拉框数据源（genderColumn 是你设计器中的列名称）
			//colGender.DataSource = genderSource;
			//colGender.ValueMember = "Key";
			//colGender.DisplayMember = "Value";

			//gridPerson.DataSource = lstPerson;
			InitGridCourse();
		}

		private void GridCourse_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			//获取选中的课程名称
			string courseName = gridCourse.Rows[e.RowIndex].Cells["ColName"].Value?.ToString();
			BtnCurrentClick.Text = $"{courseName}\r\n\r\n选课人数：200人";

			this.Close();
		}

		private void dataGridView1_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0 && e.RowIndex != lastRowIndex)
			{
				// 清除上一行颜色
				if (lastRowIndex >= 0 && lastRowIndex < gridCourse.Rows.Count)
				{
					gridCourse.Rows[lastRowIndex].DefaultCellStyle.BackColor =
						lastRowIndex % 2 == 0 ? normalColor : Color.FromArgb(240, 240, 240);
				}

				// 设置当前行高亮
				gridCourse.Rows[e.RowIndex].DefaultCellStyle.BackColor = hoverColor;
				lastRowIndex = e.RowIndex;
			}
		}

		private void dataGridView1_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
		{
			// 清除颜色，仅当鼠标离开表格区域时
			if (!gridCourse.ClientRectangle.Contains(gridCourse.PointToClient(Cursor.Position)))
			{
				if (lastRowIndex >= 0 && lastRowIndex < gridCourse.Rows.Count)
				{
					gridCourse.Rows[lastRowIndex].DefaultCellStyle.BackColor =
						lastRowIndex % 2 == 0 ? normalColor : Color.FromArgb(240, 240, 240);
					lastRowIndex = -1;
				}
			}
		}

		public void InitGridCourse()
		{
			if (lstCourse == null || lstCourse.Count == 0)
			{
				gridCourse.DataSource = null;
				labPageInfo.Text = "第 0 页，共 0 页";
				return;
			}

			// 计算总页数
			totalPage = (int)Math.Ceiling((double)lstCourse.Count / pageSize);

			// 控制当前页在合法范围内
			if (currentPage < 1) currentPage = 1;
			if (currentPage > totalPage) currentPage = totalPage;

			// 分页获取数据
			var pagedData = lstCourse
				.Skip((currentPage - 1) * pageSize)
				.Take(pageSize)
				.ToList();

			// 绑定数据到 DataGridView
			gridCourse.DataSource = pagedData;

			// 更新分页信息显示
			labPageInfo.Text = $"第 {currentPage} 页，共 {totalPage} 页";
		}

		//首页
		private void btnFirstPage_Click(object sender, EventArgs e)
		{
			currentPage = 1;
			InitGridCourse();
		}
		//上一页
		private void btnPreviousPage_Click(object sender, EventArgs e)
		{
			if (currentPage > 1)
			{
				currentPage--;
				InitGridCourse();
			}
		}
		//下一页
		private void btnNextPage_Click(object sender, EventArgs e)
		{
			if (currentPage < totalPage)
			{
				currentPage++;
				InitGridCourse();
			}
		}
		//尾页
		private void btnLastPage_Click(object sender, EventArgs e)
		{
			currentPage = totalPage;
			InitGridCourse();
		}

	}
}

