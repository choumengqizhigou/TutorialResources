﻿using MaanshanTeachersCollege.ControlsUC;
using MaanshanTeachersCollege.Enums;
using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Pages;
using NPOI.OpenXmlFormats.Dml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.Expando;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MaanshanTeachersCollege
{
	public partial class EditPersonForm : Form
	{
		/// <summary>
		/// 当前打开的人员Page页面
		/// </summary>
		PersonnelManagementPageUC CurrentPageUC;
		//当前传送过来的人员信息模型
		PersonnelModel CurrentPersonelModel;
		public EditPersonForm(PersonnelManagementPageUC pageUC, PersonnelModel model)
		{
			InitializeComponent();

			CurrentPageUC = pageUC;

			var genderList = Enum.GetValues(typeof(GenderEnum))
								 .Cast<GenderEnum>()
								 .Select(g => new
								 {
									 Text = g.ToString(),
									 Value = g
								 })
								 .ToList();


			cmbGender.DisplayMember = "Text";
			cmbGender.ValueMember = "Value";
			cmbGender.DataSource = genderList;

			CurrentPersonelModel = model;
			labID.Text = model.ID;
			txtName.Text = model.Name;
			// 设置 ComboBox 当前选中项为模型值
			cmbGender.SelectedValue = model.Gender;
			txtIDNumber.Text = model.IDNumber;
			txtAddress.Text = model.Address;
			// 固定大小
			//this.Width = 1366;
			//this.Height = 768;
			//this.FormBorderStyle = FormBorderStyle.FixedSingle;
			this.StartPosition = FormStartPosition.CenterScreen;
			//this.MaximizeBox = false;
		}

		public EditPersonForm()
		{
			InitializeComponent();


			// 固定大小
			//this.Width = 1366;
			//this.Height = 768;
			//this.FormBorderStyle = FormBorderStyle.FixedSingle;
			this.StartPosition = FormStartPosition.CenterScreen;
			//this.MaximizeBox = false;
		}

		private void btnEditPerson_Click(object sender, EventArgs e)
		{
			if(CurrentPersonelModel==null)
			{
				MessageBox.Show("没有啦，别看了！！！");
				return;
			}

			CurrentPersonelModel.ID = labID.Text;
			CurrentPersonelModel.Name = txtName.Text;
			if (cmbGender.SelectedValue is GenderEnum selectedGender)
			{
				CurrentPersonelModel.Gender = selectedGender;
			}
			CurrentPersonelModel.IDNumber = txtIDNumber.Text;
			CurrentPersonelModel.Address = txtAddress.Text;

			CurrentPageUC.InitGridPerson();

			this.Close();
		}
	}
}
