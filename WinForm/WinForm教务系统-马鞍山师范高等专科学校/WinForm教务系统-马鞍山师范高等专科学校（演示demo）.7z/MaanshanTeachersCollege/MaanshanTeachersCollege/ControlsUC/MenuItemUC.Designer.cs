﻿namespace MaanshanTeachersCollege.ControlsUC
{
	partial class MenuItemUC
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.labMenuText = new System.Windows.Forms.Label();
			this.picMenuExpand = new System.Windows.Forms.PictureBox();
			this.picIcon = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.picMenuExpand)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.picIcon)).BeginInit();
			this.SuspendLayout();
			// 
			// labMenuText
			// 
			this.labMenuText.AutoSize = true;
			this.labMenuText.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.labMenuText.ForeColor = System.Drawing.Color.White;
			this.labMenuText.Location = new System.Drawing.Point(70, 12);
			this.labMenuText.Name = "labMenuText";
			this.labMenuText.Size = new System.Drawing.Size(42, 22);
			this.labMenuText.TabIndex = 1;
			this.labMenuText.Text = "首页";
			// 
			// picMenuExpand
			// 
			this.picMenuExpand.Image = global::MaanshanTeachersCollege.Properties.Resources.expand;
			this.picMenuExpand.Location = new System.Drawing.Point(202, 11);
			this.picMenuExpand.Name = "picMenuExpand";
			this.picMenuExpand.Size = new System.Drawing.Size(24, 24);
			this.picMenuExpand.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.picMenuExpand.TabIndex = 3;
			this.picMenuExpand.TabStop = false;
			this.picMenuExpand.Visible = false;
			// 
			// picIcon
			// 
			this.picIcon.Image = global::MaanshanTeachersCollege.Properties.Resources.home;
			this.picIcon.Location = new System.Drawing.Point(20, 7);
			this.picIcon.Name = "picIcon";
			this.picIcon.Size = new System.Drawing.Size(32, 32);
			this.picIcon.TabIndex = 2;
			this.picIcon.TabStop = false;
			// 
			// MenuItemUC
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(40)))), ((int)(((byte)(45)))));
			this.Controls.Add(this.picMenuExpand);
			this.Controls.Add(this.picIcon);
			this.Controls.Add(this.labMenuText);
			this.Cursor = System.Windows.Forms.Cursors.Hand;
			this.Margin = new System.Windows.Forms.Padding(0);
			this.Name = "MenuItemUC";
			this.Size = new System.Drawing.Size(240, 50);
			((System.ComponentModel.ISupportInitialize)(this.picMenuExpand)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.picIcon)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label labMenuText;
		private System.Windows.Forms.PictureBox picIcon;
		private System.Windows.Forms.PictureBox picMenuExpand;
	}
}
