﻿namespace MaanshanTeachersCollege.ControlsUC
{
	partial class MenuUC
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.layoutMenu = new System.Windows.Forms.FlowLayoutPanel();
			this.timerExpand = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// layoutMenu
			// 
			this.layoutMenu.Dock = System.Windows.Forms.DockStyle.Fill;
			this.layoutMenu.Location = new System.Drawing.Point(0, 0);
			this.layoutMenu.Margin = new System.Windows.Forms.Padding(0);
			this.layoutMenu.Name = "layoutMenu";
			this.layoutMenu.Size = new System.Drawing.Size(240, 200);
			this.layoutMenu.TabIndex = 0;
			// 
			// timerExpand
			// 
			this.timerExpand.Interval = 10;
			this.timerExpand.Tick += new System.EventHandler(this.timerExpand_Tick);
			// 
			// MenuUC
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.layoutMenu);
			this.Margin = new System.Windows.Forms.Padding(0);
			this.Name = "MenuUC";
			this.Size = new System.Drawing.Size(240, 200);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.FlowLayoutPanel layoutMenu;
		private System.Windows.Forms.Timer timerExpand;
	}
}
