﻿using MaanshanTeachersCollege.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaanshanTeachersCollege.ControlsUC
{
	public partial class MenuItemUC : UserControl
	{
		private Color baseColor = Color.FromArgb(35,40,45);
		private Color hoverColor;
		private Color pressedColor;

		/// <summary>
		/// 修改子菜单状态
		/// </summary>
		public void ChangeSubMenuState()
		{
			//picIcon.Left += 25;
			labMenuText.Left += 10;
		}

		//父菜单启用收缩
		public void ChangeEnableMenuExpand()
		{
			picMenuExpand.Visible = true;
		}

		// 修改展开/收缩图片
		public void SetExpandIcon(Image icon)
		{
			picMenuExpand.Image = icon;
		}

		public event EventHandler Clicked;

		public MenuItemUC(string menuIcon,string menuText)
		{
			InitializeComponent();

			picIcon.Image = GetBitmapFromResx(menuIcon);
			labMenuText.Text = menuText;

			hoverColor = MakeLighter(baseColor, 0.2f);
			pressedColor = MakeDarker(baseColor, 0.2f);

			//查找所有控件，挨个赋值
			foreach (Control itemControl in this.Controls) {
				itemControl.MouseEnter += (s, e) => { this.BackColor = hoverColor; };
				itemControl.MouseLeave += (s, e) => { this.BackColor = baseColor; };
				itemControl.MouseDown += (s, e) => { this.BackColor = pressedColor; };
				itemControl.MouseUp += (s, e) => { this.BackColor = hoverColor; };

				itemControl.Click += (s, e) => Clicked?.Invoke(this, EventArgs.Empty);
			}

			this.MouseEnter += (s, e) => { this.BackColor = hoverColor; };
			this.MouseLeave += (s, e) => { this.BackColor = baseColor; };
			this.MouseDown += (s, e) => { this.BackColor = pressedColor; };
			this.MouseUp += (s, e) => { this.BackColor = hoverColor; };

			this.Click += (s, e) => Clicked?.Invoke(this, EventArgs.Empty);

			//picIcon.MouseEnter += (s, e) => { this.BackColor = hoverColor; };
			//picIcon.MouseLeave += (s, e) => { this.BackColor = baseColor; };
			//picIcon.MouseDown += (s, e) => { this.BackColor = pressedColor; };
			//picIcon.MouseUp += (s, e) => { this.BackColor = hoverColor; };

			//labMenuName.MouseEnter += (s, e) => { this.BackColor = hoverColor; };
			//labMenuName.MouseLeave += (s, e) => { this.BackColor = baseColor; };
			//labMenuName.MouseDown += (s, e) => { this.BackColor = pressedColor; };
			//labMenuName.MouseUp += (s, e) => { this.BackColor = hoverColor; };

			//picMenuExpand.MouseEnter += (s, e) => { this.BackColor = hoverColor; };
			//picMenuExpand.MouseLeave += (s, e) => { this.BackColor = baseColor; };
			//picMenuExpand.MouseDown += (s, e) => { this.BackColor = pressedColor; };
			//picMenuExpand.MouseUp += (s, e) => { this.BackColor = hoverColor; };


			//this.Click += (s, e) => Clicked?.Invoke(this, EventArgs.Empty);
		}

		public static Bitmap GetBitmapFromResx(string key)
		{
			// 确保首字母大写匹配资源键，比如 "home" -> "Home"
			//string correctedKey = char.ToUpper(key[0]) + key.Substring(1);

			PropertyInfo prop = typeof(Properties.Resources).GetProperty(key, BindingFlags.Public | BindingFlags.Static| BindingFlags.NonPublic);
			if (prop != null && prop.PropertyType == typeof(Bitmap))
			{
				return (Bitmap)prop.GetValue(null, null);
			}

			return null;
		}



		private Color MakeLighter(Color color, float factor = 0.2f)
		{
			int r = color.R + (int)((255 - color.R) * factor);
			int g = color.G + (int)((255 - color.G) * factor);
			int b = color.B + (int)((255 - color.B) * factor);
			return Color.FromArgb(r, g, b);
		}

		private Color MakeDarker(Color color, float factor = 0.2f)
		{
			int r = (int)(color.R * (1 - factor));
			int g = (int)(color.G * (1 - factor));
			int b = (int)(color.B * (1 - factor));
			return Color.FromArgb(r, g, b);
		}
	}
}
