﻿using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.Expando;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaanshanTeachersCollege.ControlsUC
{
	public partial class MenuUC : UserControl
	{
		public int MenuMinHeight { get; set; } = 50;
		public int MenuMaxHeight { get; set; } = 50;

		private bool IsExpand = false;

		MenuItemUC menuUC;

		public MenuUC(MenuModel model)
		{
			InitializeComponent();

			//先创建MenuItem 父
			menuUC = new MenuItemUC(model.MenuIcon, model.MenuText);
			menuUC.Clicked += (s, e) => ToggleExpand();
			menuUC.ChangeEnableMenuExpand();

			layoutMenu.Controls.Add(menuUC);



			//再创建MenuItem 子
			foreach (var itemSub in model.SubMenu)
			{
				MenuItemUC subMenuUC = new MenuItemUC(itemSub.MenuIcon, itemSub.MenuText);
				subMenuUC.ChangeSubMenuState();
				subMenuUC.Clicked += (s, e) =>
				{
					// 子菜单点击跳转
					MyGlobalSingleton.Instance.LoadPageUC(itemSub.MenuName,itemSub.MenuText);
				};
				layoutMenu.Controls.Add(subMenuUC);

				MenuMaxHeight += 50;
			}

			this.Height= MenuMinHeight;
		}

		private void ToggleExpand()
		{
			if (timerExpand.Enabled)
				return;
			timerExpand.Start();
		}

		private void timerExpand_Tick(object sender, EventArgs e)
		{
			if (IsExpand)
			{
				menuUC.SetExpandIcon(Resources.expand);

				this.Height -= 10;
				if (this.Height <= MenuMinHeight)
				{
					this.Height = MenuMinHeight;
					IsExpand = false;
					timerExpand.Stop();
				}
			}
			else
			{
				menuUC.SetExpandIcon(Resources.collapse);

				this.Height += 10;
				if (this.Height >= MenuMaxHeight)
				{
					this.Height = MenuMaxHeight;

					IsExpand = true;
					timerExpand.Stop();
				}
			}
		}
	}
}
