﻿namespace MaanshanTeachersCollege
{
	partial class CourseSelectionForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this.btnFirstPage = new System.Windows.Forms.Button();
			this.btnPreviousPage = new System.Windows.Forms.Button();
			this.labPageInfo = new System.Windows.Forms.Label();
			this.btnNextPage = new System.Windows.Forms.Button();
			this.btnLastPage = new System.Windows.Forms.Button();
			this.gridCourse = new System.Windows.Forms.DataGridView();
			this.panel1 = new System.Windows.Forms.Panel();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.ColNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colGender = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColIdNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tableLayoutPanel1.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridCourse)).BeginInit();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 2;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(1020, 469);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.ColumnCount = 1;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel2.Controls.Add(this.flowLayoutPanel2, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.gridCourse, 0, 0);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 83);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 2;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(1014, 383);
			this.tableLayoutPanel2.TabIndex = 1;
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this.btnFirstPage);
			this.flowLayoutPanel2.Controls.Add(this.btnPreviousPage);
			this.flowLayoutPanel2.Controls.Add(this.labPageInfo);
			this.flowLayoutPanel2.Controls.Add(this.btnNextPage);
			this.flowLayoutPanel2.Controls.Add(this.btnLastPage);
			this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 336);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(1008, 44);
			this.flowLayoutPanel2.TabIndex = 3;
			// 
			// btnFirstPage
			// 
			this.btnFirstPage.BackColor = System.Drawing.Color.White;
			this.btnFirstPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnFirstPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnFirstPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnFirstPage.Image = global::MaanshanTeachersCollege.Properties.Resources.first;
			this.btnFirstPage.Location = new System.Drawing.Point(3, 6);
			this.btnFirstPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnFirstPage.Name = "btnFirstPage";
			this.btnFirstPage.Size = new System.Drawing.Size(30, 30);
			this.btnFirstPage.TabIndex = 7;
			this.btnFirstPage.UseVisualStyleBackColor = false;
			this.btnFirstPage.Click += new System.EventHandler(this.btnFirstPage_Click);
			// 
			// btnPreviousPage
			// 
			this.btnPreviousPage.BackColor = System.Drawing.Color.White;
			this.btnPreviousPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnPreviousPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnPreviousPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPreviousPage.Image = global::MaanshanTeachersCollege.Properties.Resources.pageup;
			this.btnPreviousPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPreviousPage.Location = new System.Drawing.Point(39, 6);
			this.btnPreviousPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnPreviousPage.Name = "btnPreviousPage";
			this.btnPreviousPage.Size = new System.Drawing.Size(90, 30);
			this.btnPreviousPage.TabIndex = 2;
			this.btnPreviousPage.Text = "上一页";
			this.btnPreviousPage.UseVisualStyleBackColor = false;
			this.btnPreviousPage.Click += new System.EventHandler(this.btnPreviousPage_Click);
			// 
			// labPageInfo
			// 
			this.labPageInfo.AutoSize = true;
			this.labPageInfo.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.labPageInfo.Location = new System.Drawing.Point(142, 10);
			this.labPageInfo.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.labPageInfo.Name = "labPageInfo";
			this.labPageInfo.Size = new System.Drawing.Size(175, 19);
			this.labPageInfo.TabIndex = 4;
			this.labPageInfo.Text = "第 0 页，共 0 页";
			// 
			// btnNextPage
			// 
			this.btnNextPage.BackColor = System.Drawing.Color.White;
			this.btnNextPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnNextPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnNextPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnNextPage.Image = global::MaanshanTeachersCollege.Properties.Resources.pagedown;
			this.btnNextPage.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnNextPage.Location = new System.Drawing.Point(330, 6);
			this.btnNextPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnNextPage.Name = "btnNextPage";
			this.btnNextPage.Size = new System.Drawing.Size(90, 30);
			this.btnNextPage.TabIndex = 3;
			this.btnNextPage.Text = "下一页";
			this.btnNextPage.UseVisualStyleBackColor = false;
			this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
			// 
			// btnLastPage
			// 
			this.btnLastPage.BackColor = System.Drawing.Color.White;
			this.btnLastPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnLastPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnLastPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLastPage.Image = global::MaanshanTeachersCollege.Properties.Resources.last;
			this.btnLastPage.Location = new System.Drawing.Point(426, 6);
			this.btnLastPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnLastPage.Name = "btnLastPage";
			this.btnLastPage.Size = new System.Drawing.Size(30, 30);
			this.btnLastPage.TabIndex = 6;
			this.btnLastPage.UseVisualStyleBackColor = false;
			this.btnLastPage.Click += new System.EventHandler(this.btnLastPage_Click);
			// 
			// gridCourse
			// 
			this.gridCourse.BackgroundColor = System.Drawing.Color.White;
			this.gridCourse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColNumber,
            this.ColName,
            this.colGender,
            this.ColIdNumber,
            this.colAddress});
			this.gridCourse.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gridCourse.Location = new System.Drawing.Point(3, 3);
			this.gridCourse.Name = "gridCourse";
			this.gridCourse.RowTemplate.Height = 23;
			this.gridCourse.Size = new System.Drawing.Size(1008, 327);
			this.gridCourse.TabIndex = 0;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.panel1.Controls.Add(this.pictureBox2);
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Margin = new System.Windows.Forms.Padding(0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1020, 80);
			this.panel1.TabIndex = 0;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = global::MaanshanTeachersCollege.Properties.Resources.LogoSecondary;
			this.pictureBox2.Location = new System.Drawing.Point(560, 27);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(450, 49);
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::MaanshanTeachersCollege.Properties.Resources.LogoMain;
			this.pictureBox1.Location = new System.Drawing.Point(5, 5);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(555, 71);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// ColNumber
			// 
			this.ColNumber.DataPropertyName = "CourseID";
			this.ColNumber.HeaderText = "课程ID";
			this.ColNumber.Name = "ColNumber";
			// 
			// ColName
			// 
			this.ColName.DataPropertyName = "CourseName";
			this.ColName.HeaderText = "课程名称";
			this.ColName.Name = "ColName";
			// 
			// colGender
			// 
			this.colGender.DataPropertyName = "CourseTeacher";
			this.colGender.HeaderText = "授课老师";
			this.colGender.Name = "colGender";
			this.colGender.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			// 
			// ColIdNumber
			// 
			this.ColIdNumber.DataPropertyName = "CourseClassroom";
			this.ColIdNumber.HeaderText = "授课教室";
			this.ColIdNumber.Name = "ColIdNumber";
			// 
			// colAddress
			// 
			this.colAddress.DataPropertyName = "CourseObjectives";
			this.colAddress.HeaderText = "课程目的";
			this.colAddress.MinimumWidth = 250;
			this.colAddress.Name = "colAddress";
			this.colAddress.Width = 250;
			// 
			// CourseSelectionForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(1020, 469);
			this.Controls.Add(this.tableLayoutPanel1);
			this.Name = "CourseSelectionForm";
			this.Text = "教学管理系统 - 马鞍山师范高等专科学校";
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridCourse)).EndInit();
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private System.Windows.Forms.Button btnFirstPage;
		private System.Windows.Forms.Button btnPreviousPage;
		private System.Windows.Forms.Label labPageInfo;
		private System.Windows.Forms.Button btnNextPage;
		private System.Windows.Forms.Button btnLastPage;
		private System.Windows.Forms.DataGridView gridCourse;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColNumber;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColName;
		private System.Windows.Forms.DataGridViewTextBoxColumn colGender;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColIdNumber;
		private System.Windows.Forms.DataGridViewTextBoxColumn colAddress;
	}
}