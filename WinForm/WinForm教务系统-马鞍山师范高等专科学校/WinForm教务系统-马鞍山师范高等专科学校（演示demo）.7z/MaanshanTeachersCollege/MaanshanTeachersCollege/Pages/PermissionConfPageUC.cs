﻿using MaanshanTeachersCollege.Enums;
using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Properties;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaanshanTeachersCollege.Pages
{
	public partial class PermissionConfPageUC : UserControl
	{
		private int pageSize = 10; // 每页显示数量
		private int currentPage = 1; // 当前页
		private int totalPage = 0; // 总页数

		List<MenuPermissionModel> lstPermission { get; set; } = new List<MenuPermissionModel>();

		public void BeautifyDataGridView(DataGridView dgv)
		{
			dgv.AutoGenerateColumns = false;
			dgv.RowHeadersVisible = false;

			dgv.EnableHeadersVisualStyles = false;
			dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(46, 87, 162);
			dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
			dgv.ColumnHeadersDefaultCellStyle.Font = new Font("微软雅黑", 10, FontStyle.Bold);
			dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			dgv.ColumnHeadersHeight = 40; // 可根据需要调整高度

			dgv.DefaultCellStyle.BackColor = Color.White;
			dgv.DefaultCellStyle.ForeColor = Color.Black;
			dgv.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
			dgv.DefaultCellStyle.SelectionForeColor = Color.Black;
			dgv.DefaultCellStyle.Font = new Font("微软雅黑", 10);
			dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);

			dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			dgv.RowTemplate.Height = 30;
			dgv.BorderStyle = System.Windows.Forms.BorderStyle.None;
			dgv.GridColor = Color.LightGray;

			dgv.AllowUserToAddRows = false;
			dgv.AllowUserToDeleteRows = false;
			dgv.AllowUserToResizeRows = false;
			//dgv.ReadOnly = true;
			dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		}

		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
			{
				var dgv = (DataGridView)sender;
				if (dgv.Columns[e.ColumnIndex] is DataGridViewComboBoxColumn)
				{
					dgv.BeginEdit(true);

					if (dgv.EditingControl is ComboBox comboBox)
					{
						comboBox.DroppedDown = true;
					}
				}
			}
		}

		Color hoverColor = Color.LightSkyBlue;
		Color normalColor = Color.White;

		private int lastRowIndex = -1;

		private void dataGridView1_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0 && e.RowIndex != lastRowIndex)
			{
				// 清除上一行颜色
				if (lastRowIndex >= 0 && lastRowIndex < gridCourse.Rows.Count)
				{
					gridCourse.Rows[lastRowIndex].DefaultCellStyle.BackColor =
						lastRowIndex % 2 == 0 ? normalColor : Color.FromArgb(240, 240, 240);
				}

				// 设置当前行高亮
				gridCourse.Rows[e.RowIndex].DefaultCellStyle.BackColor = hoverColor;
				lastRowIndex = e.RowIndex;
			}
		}

		private void dataGridView1_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
		{
			// 清除颜色，仅当鼠标离开表格区域时
			if (!gridCourse.ClientRectangle.Contains(gridCourse.PointToClient(Cursor.Position)))
			{
				if (lastRowIndex >= 0 && lastRowIndex < gridCourse.Rows.Count)
				{
					gridCourse.Rows[lastRowIndex].DefaultCellStyle.BackColor =
						lastRowIndex % 2 == 0 ? normalColor : Color.FromArgb(240, 240, 240);
					lastRowIndex = -1;
				}
			}
		}

		private int CurrenRoletValue { get; set; }
		public PermissionConfPageUC()
		{
			InitializeComponent();

			//加载角色
			cmbRoles.DisplayMember = "RoleName";
			cmbRoles.ValueMember = "RoleID";
			cmbRoles.DataSource = MyGlobalSingleton.Instance.LstRole;

			////调整grid样式 列铺满
			//gridPerson.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			////列标题居中
			//gridPerson.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			//单元格内容居中
			foreach (DataGridViewColumn item in this.gridCourse.Columns)
			{
				item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				item.SortMode = DataGridViewColumnSortMode.NotSortable;//列标题右边有预留一个排序小箭头的位置，所以整个列标题就向左边多一点，而当把SortMode属性设置为NotSortable时，不使用排序，也就没有那个预留的位置，所有完全居中了
			}
			////选择整行
			//gridPerson.SelectionMode= DataGridViewSelectionMode.FullRowSelect;
			BeautifyDataGridView(gridCourse);

			gridCourse.CellClick += dataGridView1_CellClick;
			gridCourse.CellMouseEnter += dataGridView1_CellMouseEnter;
			gridCourse.CellMouseLeave += dataGridView1_CellMouseLeave;

			//gridPerson.EditMode = DataGridViewEditMode.EditOnEnter;

			//菜单编号
			int i = 1;
			int j = 1;

			//加载数据
			foreach (var itemMenu in MyGlobalSingleton.Instance.CurrentLoginUser.MenuItems)
			{
				MenuPermissionModel model = new MenuPermissionModel();

				lstPermission.Add(new MenuPermissionModel
				{
					MenuID = i.ToString(),
					PMenuName = itemMenu.MenuText,
					SMenuName = itemMenu.MenuText,
					IsAdd = true,
					IsDelete = true,
					IsModify = true,
					IsCheck = true
				});

				if (itemMenu.SubMenu != null && itemMenu.SubMenu.Count > 0)
				{
					foreach (var itemSubMenu in itemMenu.SubMenu)
					{
						lstPermission.Add(new MenuPermissionModel
						{
							MenuID = $"{i.ToString()}.{j.ToString()}",
							PMenuName = "",
							SMenuName = itemSubMenu.MenuText,
							IsAdd = true,
							IsDelete = true,
							IsModify = true,
							IsCheck = true
						});
						//子菜单编号+1
						j++;
					}
				}

				//菜单编号+1 重置子菜单编号
				i++;
				j = 1;
			}


			//var multiSelectColumn = new DataGridViewMultiSelectColumn()
			//{
			//	HeaderText = "多选列",
			//	Name = "multiSelectColumn",
			//	DataPropertyName = "Tags" // 对应你的数据模型中的 string 字段
			//};

			//gridPerson.Columns.Add(multiSelectColumn);


			//var genderSource = new List<KeyValuePair<GenderEnum, string>>()
			//{
			//	new KeyValuePair<GenderEnum, string>(GenderEnum.男, "男"),
			//	new KeyValuePair<GenderEnum, string>(GenderEnum.女, "女")
			//};

			//// 设置下拉框数据源（genderColumn 是你设计器中的列名称）
			//colGender.DataSource = genderSource;
			//colGender.ValueMember = "Key";
			//colGender.DisplayMember = "Value";

			//gridPerson.DataSource = lstPerson;
			InitGridCourse();
		}

		/// <summary>
		/// 数据绑定，加载分页数据
		/// </summary>
		public void InitGridCourse()
		{
			if (lstPermission == null || lstPermission.Count == 0)
			{
				gridCourse.DataSource = null;
				labPageInfo.Text = "第 0 页，共 0 页";
				return;
			}

			// 计算总页数
			totalPage = (int)Math.Ceiling((double)lstPermission.Count / pageSize);

			// 控制当前页在合法范围内
			if (currentPage < 1) currentPage = 1;
			if (currentPage > totalPage) currentPage = totalPage;

			// 分页获取数据
			var pagedData = lstPermission
				.Skip((currentPage - 1) * pageSize)
				.Take(pageSize)
				.ToList();

			// 绑定数据到 DataGridView
			gridCourse.DataSource = pagedData;

			// 更新分页信息显示
			labPageInfo.Text = $"第 {currentPage} 页，共 {totalPage} 页";
		}


		//首页
		private void btnFirstPage_Click(object sender, EventArgs e)
		{
			currentPage = 1;
			InitGridCourse();
		}
		//上一页
		private void btnPreviousPage_Click(object sender, EventArgs e)
		{
			if (currentPage > 1)
			{
				currentPage--;
				InitGridCourse();
			}
		}
		//下一页
		private void btnNextPage_Click(object sender, EventArgs e)
		{
			if (currentPage < totalPage)
			{
				currentPage++;
				InitGridCourse();
			}
		}
		//尾页
		private void btnLastPage_Click(object sender, EventArgs e)
		{
			currentPage = totalPage;
			InitGridCourse();
		}

		//获取当前的value
		private void cmbRoles_SelectedIndexChanged(object sender, EventArgs e)
		{
			ComboBox box = (ComboBox)sender;

			CurrenRoletValue = int.Parse(box.SelectedValue.ToString());

			int i = 1;
			foreach (var itemMenu in lstPermission)
			{

				itemMenu.IsAdd = i % CurrenRoletValue == 0 ? true : false;
				itemMenu.IsDelete = i % CurrenRoletValue == 0 ? false : true;
				itemMenu.IsModify = i % CurrenRoletValue == 0 ? true : false;
				itemMenu.IsCheck = i % CurrenRoletValue == 0 ? false : true;
				//子菜单编号+1
				i++;
			}

			InitGridCourse();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			MessageBox.Show("别点了，都是假的！！！");
		}
	}

}
