﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaanshanTeachersCollege.Pages
{
	public partial class HomePageUC : UserControl
	{
		public HomePageUC()
		{
			InitializeComponent();

			//Label lbl = new Label
			//{
			//	Text = "主页",
			//	Dock = DockStyle.Fill,
			//	TextAlign = System.Drawing.ContentAlignment.MiddleCenter
			//};
			//this.Controls.Add(lbl);

			labUserName.Text=MyGlobalSingleton.Instance.CurrentLoginUser.UserName;
		}
	}
}
