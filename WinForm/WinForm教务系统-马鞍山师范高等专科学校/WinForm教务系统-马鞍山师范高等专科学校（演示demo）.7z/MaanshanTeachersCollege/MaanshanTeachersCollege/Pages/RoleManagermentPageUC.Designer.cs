﻿namespace MaanshanTeachersCollege.Pages
{
	partial class RoleManagermentPageUC
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this.btnFirstPage = new System.Windows.Forms.Button();
			this.btnPreviousPage = new System.Windows.Forms.Button();
			this.labPageInfo = new System.Windows.Forms.Label();
			this.btnNextPage = new System.Windows.Forms.Button();
			this.btnLastPage = new System.Windows.Forms.Button();
			this.gridCourse = new System.Windows.Forms.DataGridView();
			this.ColNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColOperation = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.button1 = new System.Windows.Forms.Button();
			this.tableLayoutPanel1.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridCourse)).BeginInit();
			this.flowLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.gridCourse, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 0, 0);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 3;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 600);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this.btnFirstPage);
			this.flowLayoutPanel2.Controls.Add(this.btnPreviousPage);
			this.flowLayoutPanel2.Controls.Add(this.labPageInfo);
			this.flowLayoutPanel2.Controls.Add(this.btnNextPage);
			this.flowLayoutPanel2.Controls.Add(this.btnLastPage);
			this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 553);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(794, 44);
			this.flowLayoutPanel2.TabIndex = 3;
			// 
			// btnFirstPage
			// 
			this.btnFirstPage.BackColor = System.Drawing.Color.White;
			this.btnFirstPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnFirstPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnFirstPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnFirstPage.Image = global::MaanshanTeachersCollege.Properties.Resources.first;
			this.btnFirstPage.Location = new System.Drawing.Point(3, 6);
			this.btnFirstPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnFirstPage.Name = "btnFirstPage";
			this.btnFirstPage.Size = new System.Drawing.Size(30, 30);
			this.btnFirstPage.TabIndex = 7;
			this.btnFirstPage.UseVisualStyleBackColor = false;
			this.btnFirstPage.Click += new System.EventHandler(this.btnFirstPage_Click);
			// 
			// btnPreviousPage
			// 
			this.btnPreviousPage.BackColor = System.Drawing.Color.White;
			this.btnPreviousPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnPreviousPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnPreviousPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPreviousPage.Image = global::MaanshanTeachersCollege.Properties.Resources.pageup;
			this.btnPreviousPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPreviousPage.Location = new System.Drawing.Point(39, 6);
			this.btnPreviousPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnPreviousPage.Name = "btnPreviousPage";
			this.btnPreviousPage.Size = new System.Drawing.Size(90, 30);
			this.btnPreviousPage.TabIndex = 2;
			this.btnPreviousPage.Text = "上一页";
			this.btnPreviousPage.UseVisualStyleBackColor = false;
			this.btnPreviousPage.Click += new System.EventHandler(this.btnPreviousPage_Click);
			// 
			// labPageInfo
			// 
			this.labPageInfo.AutoSize = true;
			this.labPageInfo.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.labPageInfo.Location = new System.Drawing.Point(142, 10);
			this.labPageInfo.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.labPageInfo.Name = "labPageInfo";
			this.labPageInfo.Size = new System.Drawing.Size(175, 19);
			this.labPageInfo.TabIndex = 4;
			this.labPageInfo.Text = "第 0 页，共 0 页";
			// 
			// btnNextPage
			// 
			this.btnNextPage.BackColor = System.Drawing.Color.White;
			this.btnNextPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnNextPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnNextPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnNextPage.Image = global::MaanshanTeachersCollege.Properties.Resources.pagedown;
			this.btnNextPage.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnNextPage.Location = new System.Drawing.Point(330, 6);
			this.btnNextPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnNextPage.Name = "btnNextPage";
			this.btnNextPage.Size = new System.Drawing.Size(90, 30);
			this.btnNextPage.TabIndex = 3;
			this.btnNextPage.Text = "下一页";
			this.btnNextPage.UseVisualStyleBackColor = false;
			this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
			// 
			// btnLastPage
			// 
			this.btnLastPage.BackColor = System.Drawing.Color.White;
			this.btnLastPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnLastPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnLastPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLastPage.Image = global::MaanshanTeachersCollege.Properties.Resources.last;
			this.btnLastPage.Location = new System.Drawing.Point(426, 6);
			this.btnLastPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnLastPage.Name = "btnLastPage";
			this.btnLastPage.Size = new System.Drawing.Size(30, 30);
			this.btnLastPage.TabIndex = 6;
			this.btnLastPage.UseVisualStyleBackColor = false;
			this.btnLastPage.Click += new System.EventHandler(this.btnLastPage_Click);
			// 
			// gridCourse
			// 
			this.gridCourse.BackgroundColor = System.Drawing.Color.White;
			this.gridCourse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColNumber,
            this.ColName,
            this.ColOperation});
			this.gridCourse.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gridCourse.Location = new System.Drawing.Point(3, 53);
			this.gridCourse.Name = "gridCourse";
			this.gridCourse.RowTemplate.Height = 23;
			this.gridCourse.Size = new System.Drawing.Size(794, 494);
			this.gridCourse.TabIndex = 0;
			this.gridCourse.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPerson_CellClick);
			this.gridCourse.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridPerson_CellMouseMove);
			this.gridCourse.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gridPerson_CellPainting);
			// 
			// ColNumber
			// 
			this.ColNumber.DataPropertyName = "RoleID";
			this.ColNumber.HeaderText = "角色ID";
			this.ColNumber.Name = "ColNumber";
			// 
			// ColName
			// 
			this.ColName.DataPropertyName = "RoleName";
			this.ColName.HeaderText = "角色名称";
			this.ColName.Name = "ColName";
			// 
			// ColOperation
			// 
			this.ColOperation.HeaderText = "操作";
			this.ColOperation.Name = "ColOperation";
			this.ColOperation.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this.button1);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(794, 44);
			this.flowLayoutPanel1.TabIndex = 2;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.White;
			this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Image = global::MaanshanTeachersCollege.Properties.Resources.plus;
			this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button1.Location = new System.Drawing.Point(3, 6);
			this.button1.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(90, 30);
			this.button1.TabIndex = 1;
			this.button1.Text = "新增";
			this.button1.UseVisualStyleBackColor = false;
			// 
			// RoleManagermentPageUC
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.tableLayoutPanel1);
			this.Name = "RoleManagermentPageUC";
			this.Size = new System.Drawing.Size(800, 600);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridCourse)).EndInit();
			this.flowLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.DataGridView gridCourse;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private System.Windows.Forms.Button btnPreviousPage;
		private System.Windows.Forms.Button btnNextPage;
		private System.Windows.Forms.Label labPageInfo;
		private System.Windows.Forms.Button btnLastPage;
		private System.Windows.Forms.Button btnFirstPage;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColNumber;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColName;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColOperation;
	}
}
