﻿using MaanshanTeachersCollege.Enums;
using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Properties;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaanshanTeachersCollege.Pages
{
	public partial class PersonnelManagementPageUC : UserControl
	{
		private int pageSize = 10; // 每页显示数量
		private int currentPage = 1; // 当前页
		private int totalPage = 0; // 总页数

		List<PersonnelModel> lstPerson { get; set; } = new List<PersonnelModel>();

		public void BeautifyDataGridView(DataGridView dgv)
		{
			dgv.AutoGenerateColumns = false;
			dgv.RowHeadersVisible = false;

			dgv.EnableHeadersVisualStyles = false;
			dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(46, 87, 162);
			dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
			dgv.ColumnHeadersDefaultCellStyle.Font = new Font("微软雅黑", 10, FontStyle.Bold);
			dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			dgv.ColumnHeadersHeight = 40; // 可根据需要调整高度

			dgv.DefaultCellStyle.BackColor = Color.White;
			dgv.DefaultCellStyle.ForeColor = Color.Black;
			dgv.DefaultCellStyle.SelectionBackColor = Color.LightBlue;
			dgv.DefaultCellStyle.SelectionForeColor = Color.Black;
			dgv.DefaultCellStyle.Font = new Font("微软雅黑", 10);
			dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(240, 240, 240);

			dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			dgv.RowTemplate.Height = 30;
			dgv.BorderStyle = System.Windows.Forms.BorderStyle.None;
			dgv.GridColor = Color.LightGray;

			dgv.AllowUserToAddRows = false;
			dgv.AllowUserToDeleteRows = false;
			dgv.AllowUserToResizeRows = false;
			dgv.ReadOnly = true;
			dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		}

		private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
			{
				var dgv = (DataGridView)sender;
				if (dgv.Columns[e.ColumnIndex] is DataGridViewComboBoxColumn)
				{
					dgv.BeginEdit(true);

					if (dgv.EditingControl is ComboBox comboBox)
					{
						comboBox.DroppedDown = true;
					}
				}
			}
		}

		Color hoverColor = Color.LightSkyBlue;
		Color normalColor = Color.White;

		private int lastRowIndex = -1;

		private void dataGridView1_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex >= 0 && e.RowIndex != lastRowIndex)
			{
				// 清除上一行颜色
				if (lastRowIndex >= 0 && lastRowIndex < gridPerson.Rows.Count)
				{
					gridPerson.Rows[lastRowIndex].DefaultCellStyle.BackColor =
						lastRowIndex % 2 == 0 ? normalColor : Color.FromArgb(240, 240, 240);
				}

				// 设置当前行高亮
				gridPerson.Rows[e.RowIndex].DefaultCellStyle.BackColor = hoverColor;
				lastRowIndex = e.RowIndex;
			}
		}

		private void dataGridView1_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
		{
			// 清除颜色，仅当鼠标离开表格区域时
			if (!gridPerson.ClientRectangle.Contains(gridPerson.PointToClient(Cursor.Position)))
			{
				if (lastRowIndex >= 0 && lastRowIndex < gridPerson.Rows.Count)
				{
					gridPerson.Rows[lastRowIndex].DefaultCellStyle.BackColor =
						lastRowIndex % 2 == 0 ? normalColor : Color.FromArgb(240, 240, 240);
					lastRowIndex = -1;
				}
			}
		}

		public PersonnelManagementPageUC()
		{
			InitializeComponent();

			////调整grid样式 列铺满
			//gridPerson.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			////列标题居中
			//gridPerson.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			//单元格内容居中
			foreach (DataGridViewColumn item in this.gridPerson.Columns)
			{
				item.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				item.SortMode = DataGridViewColumnSortMode.NotSortable;//列标题右边有预留一个排序小箭头的位置，所以整个列标题就向左边多一点，而当把SortMode属性设置为NotSortable时，不使用排序，也就没有那个预留的位置，所有完全居中了
			}
			////选择整行
			//gridPerson.SelectionMode= DataGridViewSelectionMode.FullRowSelect;
			BeautifyDataGridView(gridPerson);

			gridPerson.CellClick += dataGridView1_CellClick;
			gridPerson.CellMouseEnter += dataGridView1_CellMouseEnter;
			gridPerson.CellMouseLeave += dataGridView1_CellMouseLeave;

			//gridPerson.EditMode = DataGridViewEditMode.EditOnEnter;

			//加载数据
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250529",
				Name = "张三",
				Gender = GenderEnum.男,
				IDNumber = "342626199305402423",
				Address = "安徽省马鞍山市和县陋室铭陋室公园"
			});
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250528",
				Name = "王五",
				Gender = GenderEnum.男,
				IDNumber = "262612199305402423",
				Address = "安徽省马鞍山市采石矶5A风景区"
			});
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250527",
				Name = "赵六",
				Gender = GenderEnum.女,
				IDNumber = "152365199305402423",
				Address = "安徽省马鞍山市马鞍山师范高等专科学校"
			});
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250526",
				Name = "王二麻子",
				Gender = GenderEnum.女,
				IDNumber = "342626199741201233",
				Address = "安徽省马鞍山市和县乌江霸王祠"
			});
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250525",
				Name = "小明",
				Gender = GenderEnum.女,
				IDNumber = "342626199741201233",
				Address = "安徽省马鞍山市含山县褒禅山景区"
			});
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250525",
				Name = "糖鸡屎",
				Gender = GenderEnum.男,
				IDNumber = "342626199741201233",
				Address = "安徽省马鞍山市和县猿人遗址"
			});
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250524",
				Name = "莱斯",
				Gender = GenderEnum.男,
				IDNumber = "342626199757893625",
				Address = "安徽省马鞍山市含山县凌家滩遗址"
			});
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250523",
				Name = "歇逼",
				Gender = GenderEnum.男,
				IDNumber = "342626199757893625",
				Address = "安徽省马鞍山市当涂县李白文化园"
			});
			lstPerson.Add(new PersonnelModel()
			{
				ID = "20250522",
				Name = "个照",
				Gender = GenderEnum.男,
				IDNumber = "342626199757893635",
				Address = "安徽省马鞍山市当涂县大青山"
			});

			//var multiSelectColumn = new DataGridViewMultiSelectColumn()
			//{
			//	HeaderText = "多选列",
			//	Name = "multiSelectColumn",
			//	DataPropertyName = "Tags" // 对应你的数据模型中的 string 字段
			//};

			//gridPerson.Columns.Add(multiSelectColumn);


			//var genderSource = new List<KeyValuePair<GenderEnum, string>>()
			//{
			//	new KeyValuePair<GenderEnum, string>(GenderEnum.男, "男"),
			//	new KeyValuePair<GenderEnum, string>(GenderEnum.女, "女")
			//};

			//// 设置下拉框数据源（genderColumn 是你设计器中的列名称）
			//colGender.DataSource = genderSource;
			//colGender.ValueMember = "Key";
			//colGender.DisplayMember = "Value";

			//gridPerson.DataSource = lstPerson;
			InitGridPerson();
		}

		/// <summary>
		/// 数据绑定，加载分页数据
		/// </summary>
		public void InitGridPerson()
		{
			if (lstPerson == null || lstPerson.Count == 0)
			{
				gridPerson.DataSource = null;
				labPageInfo.Text = "第 0 页，共 0 页";
				return;
			}

			// 计算总页数
			totalPage = (int)Math.Ceiling((double)lstPerson.Count / pageSize);

			// 控制当前页在合法范围内
			if (currentPage < 1) currentPage = 1;
			if (currentPage > totalPage) currentPage = totalPage;

			// 分页获取数据
			var pagedData = lstPerson
				.Skip((currentPage - 1) * pageSize)
				.Take(pageSize)
				.ToList();

			// 绑定数据到 DataGridView
			gridPerson.DataSource = pagedData;

			// 更新分页信息显示
			labPageInfo.Text = $"第 {currentPage} 页，共 {totalPage} 页";
		}

		private void gridPerson_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
		{
			if (e.ColumnIndex == gridPerson.Columns["ColOperation"].Index && e.RowIndex >= 0)
			{
				e.PaintBackground(e.CellBounds, true);
				int iconWidth = 22;
				int spacing = 5;
				int totalWidth = 2 * iconWidth + 1 * spacing;
				int startX = e.CellBounds.Left + (e.CellBounds.Width - totalWidth) / 2;
				int y = e.CellBounds.Top + (e.CellBounds.Height - iconWidth) / 2;

				e.Graphics.DrawImage(Resources.edit, new Rectangle(startX, y, iconWidth, iconWidth));
				e.Graphics.DrawImage(Resources.delete, new Rectangle(startX + iconWidth + spacing, y, iconWidth, iconWidth));
				//e.Graphics.DrawImage(Resources.home, new Rectangle(startX + 2 * (iconWidth + spacing), y, iconWidth, iconWidth));

				e.Handled = true;
			}
		}

		private void gridPerson_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.ColumnIndex == gridPerson.Columns["ColOperation"].Index && e.RowIndex >= 0)
			{
				var cellRect = gridPerson.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
				var clickPoint = gridPerson.PointToClient(Cursor.Position);
				int x = clickPoint.X - cellRect.X;

				int iconWidth = 22;
				int spacing = 5;
				int totalWidth = 2 * iconWidth + 1 * spacing;
				int startX = (cellRect.Width - totalWidth) / 2;

				// 获取整行数据（比如第一列是 Name）
				var row = gridPerson.Rows[e.RowIndex];
				//学号，根据学号来调整数据
				string id = row.Cells["ColNumber"].Value?.ToString();
				string name = row.Cells["ColName"].Value?.ToString();

				if (x >= startX && x < startX + iconWidth)
				{
					PersonnelModel model=new PersonnelModel();
					foreach (var item in lstPerson)
					{
						if(item.ID==id)
						{
							model = item;
							break;
						}
					}

					//MessageBox.Show($"点击了编辑:{id}");
					EditPersonForm form = new EditPersonForm(this,model);
					form.ShowDialog();
				}
				else if (x >= startX + iconWidth + spacing && x < startX + 2 * iconWidth + spacing)
				{
					//提示是否要删除
					if (MessageBox.Show($"确定要删除{name}?", "学生删除提示", MessageBoxButtons.YesNo) != DialogResult.Yes)
						return;
					IEnumerable<PersonnelModel> ienumModel = lstPerson.Where(m => m.ID == id);
					if (ienumModel.Count() <= 0)
					{
						MessageBox.Show($"数据并不存在！id:{id} name:{name}");
						return;
					}
					lstPerson.Remove(ienumModel.First());

					InitGridPerson();
				}
				//else if (x >= startX + 2 * (iconWidth + spacing) && x < startX + 3 * iconWidth + 2 * spacing)
				//{
				//	MessageBox.Show("点击了确认");
				//}
			}

		}

		private void gridPerson_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
		{
			if (e.RowIndex < 0 || e.ColumnIndex < 0)
			{
				gridPerson.Cursor = Cursors.Default;
				return;
			}

			if (gridPerson.Columns[e.ColumnIndex].Name == "ColOperation")
			{
				var cellRect = gridPerson.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
				Point mousePos = gridPerson.PointToClient(Cursor.Position);
				int xInCell = mousePos.X - cellRect.X;

				// 假设图标宽度 = 16，间距 = 5，位置和 CellPainting 一致
				int iconWidth = 22;
				int spacing = 5;
				int totalWidth = 2 * iconWidth + 1 * spacing;
				int startX = (cellRect.Width - totalWidth) / 2;

				for (int i = 0; i < 2; i++)
				{
					int iconStartX = startX + i * (iconWidth + spacing);
					if (xInCell >= iconStartX && xInCell <= iconStartX + iconWidth)
					{
						gridPerson.Cursor = Cursors.Hand;
						return;
					}
				}
			}

			gridPerson.Cursor = Cursors.Default;


		}
		//首页
		private void btnFirstPage_Click(object sender, EventArgs e)
		{
			currentPage = 1;
			InitGridPerson();
		}
		//上一页
		private void btnPreviousPage_Click(object sender, EventArgs e)
		{
			if (currentPage > 1)
			{
				currentPage--;
				InitGridPerson();
			}
		}
		//下一页
		private void btnNextPage_Click(object sender, EventArgs e)
		{
			if (currentPage < totalPage)
			{
				currentPage++;
				InitGridPerson();
			}
		}
		//尾页
		private void btnLastPage_Click(object sender, EventArgs e)
		{
			currentPage = totalPage;
			InitGridPerson();
		}

		//Excel数据导入
		private void btnImportExcelData_Click(object sender, EventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop), // 获取桌面路径
				Filter = "Excel 文件 (*.xlsx)|*.xlsx",
				Title = "Excel数据导入进列表"
			};

			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				string filePath = openFileDialog.FileName;

				List<PersonnelModel> listImprot = new List<PersonnelModel>();

				using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
				{
					IWorkbook workbook = new XSSFWorkbook(fs);
					ISheet sheet = workbook.GetSheetAt(0); // 默认读取第一个sheet

					for (int i = 1; i <= sheet.LastRowNum; i++) // 跳过标题行（从第1行开始）
					{
						IRow row = sheet.GetRow(i);
						if (row == null) continue;

						var model = new PersonnelModel
						{
							ID = GetCellString(row.GetCell(0)),
							Name = GetCellString(row.GetCell(1)),
							Gender = ParseGender(GetCellString(row.GetCell(2))),
							IDNumber = GetCellString(row.GetCell(3)),
							Address = GetCellString(row.GetCell(4))
						};

						listImprot.Add(model);
					}
				}

				if(listImprot.Count>0)
				{
					lstPerson.AddRange(listImprot);
					InitGridPerson();

					MessageBox.Show("数据导入成功");
				}
				else
				{
					MessageBox.Show("没有任何数据进行导入");
				}
			}
		}

		private static string GetCellString(ICell cell)
		{
			if (cell == null) return string.Empty;
			return cell.ToString().Trim();
		}

		private static GenderEnum ParseGender(string genderStr)
		{
			return genderStr == "女" ? GenderEnum.女 : GenderEnum.男;
		}

		//Excel数据导出
		private void btnExportExcelData_Click(object sender, EventArgs e)
		{
			SaveFileDialog saveFileDialog = new SaveFileDialog
			{
				InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop), // 获取桌面路径
				FileName = $"人员数据表{DateTime.Now.ToString("yyyy-MM-dd")}.xlsx",   // 默认文件名
				Filter = "Excel表格 (*.xlsx)|*.xlsx",
				Title = "导出数据到Excel表格"
			};

			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				string filePath = saveFileDialog.FileName;

				IWorkbook workbook = new XSSFWorkbook();
				ISheet sheet = workbook.CreateSheet("人员信息");

				// 创建表头
				IRow headerRow = sheet.CreateRow(0);
				headerRow.CreateCell(0).SetCellValue("学号");
				headerRow.CreateCell(1).SetCellValue("姓名");
				headerRow.CreateCell(2).SetCellValue("性别");
				headerRow.CreateCell(3).SetCellValue("身份证号");
				headerRow.CreateCell(4).SetCellValue("家庭住址");

				// 写入数据
				for (int i = 0; i < lstPerson.Count; i++)
				{
					var person = lstPerson[i];
					IRow row = sheet.CreateRow(i + 1);
					row.CreateCell(0).SetCellValue(person.ID);
					row.CreateCell(1).SetCellValue(person.Name);
					row.CreateCell(2).SetCellValue(person.Gender.ToString());
					row.CreateCell(3).SetCellValue(person.IDNumber);
					row.CreateCell(4).SetCellValue(person.Address);
				}

				// 自动调整列宽
				for (int i = 0; i <= 4; i++)
				{
					sheet.AutoSizeColumn(i);
				}

				// 保存到文件
				using (var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write))
				{
					workbook.Write(fs);
				}

				MessageBox.Show("数据导出完成");


				//File.WriteAllText(saveFileDialog.FileName, content);
				//GlobalFunc.instance.GlobalMainForm.MainPanelInsertText($"文件导出成功", Color.Green);
			}
		}

		//新增学生
		private void btnAddPerson_Click(object sender, EventArgs e)
		{
			EditPersonForm editPersonForm = new EditPersonForm();
			editPersonForm.ShowDialog();
		}
	}

}
