﻿namespace MaanshanTeachersCollege.Pages
{
	partial class HomePageUC
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.labUserName = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label1.Location = new System.Drawing.Point(17, 34);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(89, 19);
			this.label1.TabIndex = 1;
			this.label1.Text = "欢迎您：";
			// 
			// labUserName
			// 
			this.labUserName.AutoSize = true;
			this.labUserName.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.labUserName.ForeColor = System.Drawing.Color.Red;
			this.labUserName.Location = new System.Drawing.Point(112, 24);
			this.labUserName.Name = "labUserName";
			this.labUserName.Size = new System.Drawing.Size(73, 29);
			this.labUserName.TabIndex = 2;
			this.labUserName.Text = "登录";
			// 
			// HomePageUC
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.labUserName);
			this.Controls.Add(this.label1);
			this.Name = "HomePageUC";
			this.Size = new System.Drawing.Size(800, 600);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label labUserName;
	}
}
