﻿namespace MaanshanTeachersCollege.Pages
{
	partial class CourseSelectionPageUC
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.labPageInfo = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.btnImportExcelData = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 8;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28572F));
			this.tableLayoutPanel1.Controls.Add(this.label6, 7, 0);
			this.tableLayoutPanel1.Controls.Add(this.label5, 6, 0);
			this.tableLayoutPanel1.Controls.Add(this.label4, 5, 0);
			this.tableLayoutPanel1.Controls.Add(this.label3, 4, 0);
			this.tableLayoutPanel1.Controls.Add(this.label2, 3, 0);
			this.tableLayoutPanel1.Controls.Add(this.label1, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this.labPageInfo, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.label7, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.label8, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.btnImportExcelData, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.button1, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this.button2, 3, 1);
			this.tableLayoutPanel1.Controls.Add(this.button3, 4, 1);
			this.tableLayoutPanel1.Controls.Add(this.button4, 5, 1);
			this.tableLayoutPanel1.Controls.Add(this.button5, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.button6, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this.button7, 3, 2);
			this.tableLayoutPanel1.Controls.Add(this.button8, 4, 2);
			this.tableLayoutPanel1.Controls.Add(this.button9, 5, 2);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 3;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 600);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label6.Location = new System.Drawing.Point(710, 15);
			this.label6.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(69, 19);
			this.label6.TabIndex = 11;
			this.label6.Text = "星期天";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label5.Location = new System.Drawing.Point(603, 15);
			this.label5.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(69, 19);
			this.label5.TabIndex = 10;
			this.label5.Text = "星期六";
			// 
			// label4
			// 
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label4.Location = new System.Drawing.Point(498, 15);
			this.label4.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(69, 19);
			this.label4.TabIndex = 9;
			this.label4.Text = "星期五";
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label3.Location = new System.Drawing.Point(393, 15);
			this.label3.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(69, 19);
			this.label3.TabIndex = 8;
			this.label3.Text = "星期四";
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label2.Location = new System.Drawing.Point(288, 15);
			this.label2.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(69, 19);
			this.label2.TabIndex = 7;
			this.label2.Text = "星期三";
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label1.Location = new System.Drawing.Point(183, 15);
			this.label1.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(69, 19);
			this.label1.TabIndex = 6;
			this.label1.Text = "星期二";
			// 
			// labPageInfo
			// 
			this.labPageInfo.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.labPageInfo.AutoSize = true;
			this.labPageInfo.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.labPageInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.labPageInfo.Location = new System.Drawing.Point(78, 15);
			this.labPageInfo.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.labPageInfo.Name = "labPageInfo";
			this.labPageInfo.Size = new System.Drawing.Size(69, 19);
			this.labPageInfo.TabIndex = 5;
			this.labPageInfo.Text = "星期一";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label7.Location = new System.Drawing.Point(15, 166);
			this.label7.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(29, 38);
			this.label7.TabIndex = 12;
			this.label7.Text = "上\r\n午";
			// 
			// label8
			// 
			this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.label8.Location = new System.Drawing.Point(15, 446);
			this.label8.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(29, 38);
			this.label8.TabIndex = 13;
			this.label8.Text = "下\r\n午";
			// 
			// btnImportExcelData
			// 
			this.btnImportExcelData.BackColor = System.Drawing.Color.White;
			this.btnImportExcelData.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnImportExcelData.Dock = System.Windows.Forms.DockStyle.Fill;
			this.btnImportExcelData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnImportExcelData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnImportExcelData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnImportExcelData.Location = new System.Drawing.Point(63, 43);
			this.btnImportExcelData.Name = "btnImportExcelData";
			this.btnImportExcelData.Size = new System.Drawing.Size(99, 274);
			this.btnImportExcelData.TabIndex = 14;
			this.btnImportExcelData.Tag = "";
			this.btnImportExcelData.Text = "无";
			this.btnImportExcelData.UseVisualStyleBackColor = false;
			this.btnImportExcelData.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.White;
			this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Location = new System.Drawing.Point(168, 43);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(99, 274);
			this.button1.TabIndex = 15;
			this.button1.Tag = "";
			this.button1.Text = "无";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.White;
			this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button2.Location = new System.Drawing.Point(273, 43);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(99, 274);
			this.button2.TabIndex = 16;
			this.button2.Tag = "";
			this.button2.Text = "无";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button3
			// 
			this.button3.BackColor = System.Drawing.Color.White;
			this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button3.Location = new System.Drawing.Point(378, 43);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(99, 274);
			this.button3.TabIndex = 17;
			this.button3.Tag = "";
			this.button3.Text = "无";
			this.button3.UseVisualStyleBackColor = false;
			this.button3.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.White;
			this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button4.Location = new System.Drawing.Point(483, 43);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(99, 274);
			this.button4.TabIndex = 18;
			this.button4.Tag = "";
			this.button4.Text = "无";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.White;
			this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button5.Location = new System.Drawing.Point(63, 323);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(99, 274);
			this.button5.TabIndex = 19;
			this.button5.Tag = "";
			this.button5.Text = "思想政治\r\n\r\n选课人数：200";
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button6
			// 
			this.button6.BackColor = System.Drawing.Color.White;
			this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button6.Location = new System.Drawing.Point(168, 323);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(99, 274);
			this.button6.TabIndex = 20;
			this.button6.Tag = "";
			this.button6.Text = "无";
			this.button6.UseVisualStyleBackColor = false;
			this.button6.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button7
			// 
			this.button7.BackColor = System.Drawing.Color.White;
			this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button7.Location = new System.Drawing.Point(273, 323);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(99, 274);
			this.button7.TabIndex = 21;
			this.button7.Tag = "";
			this.button7.Text = "无";
			this.button7.UseVisualStyleBackColor = false;
			this.button7.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button8
			// 
			this.button8.BackColor = System.Drawing.Color.White;
			this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button8.Location = new System.Drawing.Point(378, 323);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(99, 274);
			this.button8.TabIndex = 22;
			this.button8.Tag = "";
			this.button8.Text = "无";
			this.button8.UseVisualStyleBackColor = false;
			this.button8.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// button9
			// 
			this.button9.BackColor = System.Drawing.Color.White;
			this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button9.Location = new System.Drawing.Point(483, 323);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(99, 274);
			this.button9.TabIndex = 23;
			this.button9.Tag = "";
			this.button9.Text = "无";
			this.button9.UseVisualStyleBackColor = false;
			this.button9.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// CourseSelectionPageUC
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.tableLayoutPanel1);
			this.Name = "CourseSelectionPageUC";
			this.Size = new System.Drawing.Size(800, 600);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label labPageInfo;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button btnImportExcelData;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
	}
}
