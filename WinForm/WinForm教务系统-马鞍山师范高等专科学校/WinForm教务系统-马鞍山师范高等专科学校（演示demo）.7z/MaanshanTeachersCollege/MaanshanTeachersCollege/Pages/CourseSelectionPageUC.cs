﻿using MaanshanTeachersCollege.Enums;
using MaanshanTeachersCollege.Models;
using MaanshanTeachersCollege.Properties;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaanshanTeachersCollege.Pages
{
	public partial class CourseSelectionPageUC : UserControl
	{
		public CourseSelectionPageUC()
		{
			InitializeComponent();
		}

		private void btnImportExcelData_Click(object sender, EventArgs e)
		{
			Button btnCurrenClick = (Button)sender;

			CourseSelectionForm courseSelectionForm = new CourseSelectionForm(btnCurrenClick);
			courseSelectionForm.ShowDialog();
		}
	}

}
