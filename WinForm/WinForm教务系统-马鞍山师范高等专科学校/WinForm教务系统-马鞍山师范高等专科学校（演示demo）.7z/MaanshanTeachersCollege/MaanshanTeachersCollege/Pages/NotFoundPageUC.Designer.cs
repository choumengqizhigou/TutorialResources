﻿namespace MaanshanTeachersCollege.Pages
{
	partial class NotFoundPageUC
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.lab404 = new System.Windows.Forms.Label();
			this.lab404Text = new System.Windows.Forms.Label();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// lab404
			// 
			this.lab404.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lab404.AutoSize = true;
			this.lab404.Font = new System.Drawing.Font("微软雅黑", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.lab404.ForeColor = System.Drawing.Color.Red;
			this.lab404.Location = new System.Drawing.Point(331, 442);
			this.lab404.Name = "lab404";
			this.lab404.Size = new System.Drawing.Size(137, 75);
			this.lab404.TabIndex = 0;
			this.lab404.Text = "404";
			// 
			// lab404Text
			// 
			this.lab404Text.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lab404Text.AutoSize = true;
			this.lab404Text.Font = new System.Drawing.Font("微软雅黑", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.lab404Text.ForeColor = System.Drawing.Color.Red;
			this.lab404Text.Location = new System.Drawing.Point(160, 142);
			this.lab404Text.Name = "lab404Text";
			this.lab404Text.Size = new System.Drawing.Size(480, 75);
			this.lab404Text.TabIndex = 1;
			this.lab404Text.Text = "未找到相关页面！";
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Controls.Add(this.lab404Text, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.lab404, 0, 1);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 2;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 600);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// NotFoundPageUC
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.tableLayoutPanel1);
			this.Name = "NotFoundPageUC";
			this.Size = new System.Drawing.Size(800, 600);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label lab404;
		private System.Windows.Forms.Label lab404Text;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
	}
}
