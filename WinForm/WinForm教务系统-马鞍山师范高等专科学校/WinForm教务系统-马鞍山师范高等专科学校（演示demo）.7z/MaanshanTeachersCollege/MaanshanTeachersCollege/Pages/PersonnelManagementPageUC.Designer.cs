﻿namespace MaanshanTeachersCollege.Pages
{
	partial class PersonnelManagementPageUC
	{
		/// <summary> 
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region 组件设计器生成的代码

		/// <summary> 
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
			this.btnFirstPage = new System.Windows.Forms.Button();
			this.btnPreviousPage = new System.Windows.Forms.Button();
			this.labPageInfo = new System.Windows.Forms.Label();
			this.btnNextPage = new System.Windows.Forms.Button();
			this.btnLastPage = new System.Windows.Forms.Button();
			this.gridPerson = new System.Windows.Forms.DataGridView();
			this.ColNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colGender = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColIdNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColOperation = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.btnAddPerson = new System.Windows.Forms.Button();
			this.btnImportExcelData = new System.Windows.Forms.Button();
			this.btnExportExcelData = new System.Windows.Forms.Button();
			this.tableLayoutPanel1.SuspendLayout();
			this.flowLayoutPanel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridPerson)).BeginInit();
			this.flowLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.gridPerson, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 0, 0);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 3;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 600);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// flowLayoutPanel2
			// 
			this.flowLayoutPanel2.Controls.Add(this.btnFirstPage);
			this.flowLayoutPanel2.Controls.Add(this.btnPreviousPage);
			this.flowLayoutPanel2.Controls.Add(this.labPageInfo);
			this.flowLayoutPanel2.Controls.Add(this.btnNextPage);
			this.flowLayoutPanel2.Controls.Add(this.btnLastPage);
			this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 553);
			this.flowLayoutPanel2.Name = "flowLayoutPanel2";
			this.flowLayoutPanel2.Size = new System.Drawing.Size(794, 44);
			this.flowLayoutPanel2.TabIndex = 3;
			// 
			// btnFirstPage
			// 
			this.btnFirstPage.BackColor = System.Drawing.Color.White;
			this.btnFirstPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnFirstPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnFirstPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnFirstPage.Image = global::MaanshanTeachersCollege.Properties.Resources.first;
			this.btnFirstPage.Location = new System.Drawing.Point(3, 6);
			this.btnFirstPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnFirstPage.Name = "btnFirstPage";
			this.btnFirstPage.Size = new System.Drawing.Size(30, 30);
			this.btnFirstPage.TabIndex = 7;
			this.btnFirstPage.UseVisualStyleBackColor = false;
			this.btnFirstPage.Click += new System.EventHandler(this.btnFirstPage_Click);
			// 
			// btnPreviousPage
			// 
			this.btnPreviousPage.BackColor = System.Drawing.Color.White;
			this.btnPreviousPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnPreviousPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnPreviousPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPreviousPage.Image = global::MaanshanTeachersCollege.Properties.Resources.pageup;
			this.btnPreviousPage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnPreviousPage.Location = new System.Drawing.Point(39, 6);
			this.btnPreviousPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnPreviousPage.Name = "btnPreviousPage";
			this.btnPreviousPage.Size = new System.Drawing.Size(90, 30);
			this.btnPreviousPage.TabIndex = 2;
			this.btnPreviousPage.Text = "上一页";
			this.btnPreviousPage.UseVisualStyleBackColor = false;
			this.btnPreviousPage.Click += new System.EventHandler(this.btnPreviousPage_Click);
			// 
			// labPageInfo
			// 
			this.labPageInfo.AutoSize = true;
			this.labPageInfo.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Bold);
			this.labPageInfo.Location = new System.Drawing.Point(142, 10);
			this.labPageInfo.Margin = new System.Windows.Forms.Padding(10, 10, 10, 0);
			this.labPageInfo.Name = "labPageInfo";
			this.labPageInfo.Size = new System.Drawing.Size(175, 19);
			this.labPageInfo.TabIndex = 4;
			this.labPageInfo.Text = "第 0 页，共 0 页";
			// 
			// btnNextPage
			// 
			this.btnNextPage.BackColor = System.Drawing.Color.White;
			this.btnNextPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnNextPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnNextPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnNextPage.Image = global::MaanshanTeachersCollege.Properties.Resources.pagedown;
			this.btnNextPage.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnNextPage.Location = new System.Drawing.Point(330, 6);
			this.btnNextPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnNextPage.Name = "btnNextPage";
			this.btnNextPage.Size = new System.Drawing.Size(90, 30);
			this.btnNextPage.TabIndex = 3;
			this.btnNextPage.Text = "下一页";
			this.btnNextPage.UseVisualStyleBackColor = false;
			this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
			// 
			// btnLastPage
			// 
			this.btnLastPage.BackColor = System.Drawing.Color.White;
			this.btnLastPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnLastPage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnLastPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnLastPage.Image = global::MaanshanTeachersCollege.Properties.Resources.last;
			this.btnLastPage.Location = new System.Drawing.Point(426, 6);
			this.btnLastPage.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnLastPage.Name = "btnLastPage";
			this.btnLastPage.Size = new System.Drawing.Size(30, 30);
			this.btnLastPage.TabIndex = 6;
			this.btnLastPage.UseVisualStyleBackColor = false;
			this.btnLastPage.Click += new System.EventHandler(this.btnLastPage_Click);
			// 
			// gridPerson
			// 
			this.gridPerson.BackgroundColor = System.Drawing.Color.White;
			this.gridPerson.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColNumber,
            this.ColName,
            this.colGender,
            this.ColIdNumber,
            this.colAddress,
            this.ColOperation});
			this.gridPerson.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gridPerson.Location = new System.Drawing.Point(3, 53);
			this.gridPerson.Name = "gridPerson";
			this.gridPerson.RowTemplate.Height = 23;
			this.gridPerson.Size = new System.Drawing.Size(794, 494);
			this.gridPerson.TabIndex = 0;
			this.gridPerson.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPerson_CellClick);
			this.gridPerson.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridPerson_CellMouseMove);
			this.gridPerson.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gridPerson_CellPainting);
			// 
			// ColNumber
			// 
			this.ColNumber.DataPropertyName = "ID";
			this.ColNumber.HeaderText = "学号";
			this.ColNumber.Name = "ColNumber";
			// 
			// ColName
			// 
			this.ColName.DataPropertyName = "Name";
			this.ColName.HeaderText = "姓名";
			this.ColName.Name = "ColName";
			// 
			// colGender
			// 
			this.colGender.DataPropertyName = "Gender";
			this.colGender.HeaderText = "性别";
			this.colGender.Name = "colGender";
			this.colGender.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			// 
			// ColIdNumber
			// 
			this.ColIdNumber.DataPropertyName = "IDNumber";
			this.ColIdNumber.HeaderText = "身份证号";
			this.ColIdNumber.Name = "ColIdNumber";
			// 
			// colAddress
			// 
			this.colAddress.DataPropertyName = "Address";
			this.colAddress.HeaderText = "地址";
			this.colAddress.MinimumWidth = 250;
			this.colAddress.Name = "colAddress";
			this.colAddress.Width = 250;
			// 
			// ColOperation
			// 
			this.ColOperation.HeaderText = "操作";
			this.ColOperation.Name = "ColOperation";
			this.ColOperation.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.Controls.Add(this.btnAddPerson);
			this.flowLayoutPanel1.Controls.Add(this.btnImportExcelData);
			this.flowLayoutPanel1.Controls.Add(this.btnExportExcelData);
			this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(794, 44);
			this.flowLayoutPanel1.TabIndex = 2;
			// 
			// btnAddPerson
			// 
			this.btnAddPerson.BackColor = System.Drawing.Color.White;
			this.btnAddPerson.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnAddPerson.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnAddPerson.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAddPerson.Image = global::MaanshanTeachersCollege.Properties.Resources.plus;
			this.btnAddPerson.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAddPerson.Location = new System.Drawing.Point(3, 6);
			this.btnAddPerson.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnAddPerson.Name = "btnAddPerson";
			this.btnAddPerson.Size = new System.Drawing.Size(90, 30);
			this.btnAddPerson.TabIndex = 1;
			this.btnAddPerson.Text = "新增";
			this.btnAddPerson.UseVisualStyleBackColor = false;
			this.btnAddPerson.Click += new System.EventHandler(this.btnAddPerson_Click);
			// 
			// btnImportExcelData
			// 
			this.btnImportExcelData.BackColor = System.Drawing.Color.White;
			this.btnImportExcelData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnImportExcelData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnImportExcelData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnImportExcelData.Image = global::MaanshanTeachersCollege.Properties.Resources.import_excel;
			this.btnImportExcelData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnImportExcelData.Location = new System.Drawing.Point(99, 6);
			this.btnImportExcelData.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnImportExcelData.Name = "btnImportExcelData";
			this.btnImportExcelData.Size = new System.Drawing.Size(110, 30);
			this.btnImportExcelData.TabIndex = 2;
			this.btnImportExcelData.Tag = "";
			this.btnImportExcelData.Text = " Excel导入";
			this.btnImportExcelData.UseVisualStyleBackColor = false;
			this.btnImportExcelData.Click += new System.EventHandler(this.btnImportExcelData_Click);
			// 
			// btnExportExcelData
			// 
			this.btnExportExcelData.BackColor = System.Drawing.Color.White;
			this.btnExportExcelData.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnExportExcelData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(87)))), ((int)(((byte)(162)))));
			this.btnExportExcelData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnExportExcelData.Image = global::MaanshanTeachersCollege.Properties.Resources.export_excel;
			this.btnExportExcelData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnExportExcelData.Location = new System.Drawing.Point(215, 6);
			this.btnExportExcelData.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
			this.btnExportExcelData.Name = "btnExportExcelData";
			this.btnExportExcelData.Size = new System.Drawing.Size(110, 30);
			this.btnExportExcelData.TabIndex = 3;
			this.btnExportExcelData.Tag = "";
			this.btnExportExcelData.Text = "Excel导出";
			this.btnExportExcelData.UseVisualStyleBackColor = false;
			this.btnExportExcelData.Click += new System.EventHandler(this.btnExportExcelData_Click);
			// 
			// PersonnelManagementPageUC
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.tableLayoutPanel1);
			this.Name = "PersonnelManagementPageUC";
			this.Size = new System.Drawing.Size(800, 600);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.flowLayoutPanel2.ResumeLayout(false);
			this.flowLayoutPanel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridPerson)).EndInit();
			this.flowLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.DataGridView gridPerson;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColNumber;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColName;
		private System.Windows.Forms.DataGridViewTextBoxColumn colGender;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColIdNumber;
		private System.Windows.Forms.DataGridViewTextBoxColumn colAddress;
		private System.Windows.Forms.DataGridViewTextBoxColumn ColOperation;
		private System.Windows.Forms.Button btnAddPerson;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private System.Windows.Forms.Button btnImportExcelData;
		private System.Windows.Forms.Button btnExportExcelData;
		private System.Windows.Forms.Button btnPreviousPage;
		private System.Windows.Forms.Button btnNextPage;
		private System.Windows.Forms.Label labPageInfo;
		private System.Windows.Forms.Button btnLastPage;
		private System.Windows.Forms.Button btnFirstPage;
	}
}
