﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaanshanTeachersCollege.Pages
{
	public partial class NotFoundPageUC : UserControl
	{
		public NotFoundPageUC(string pageText)
		{
			InitializeComponent();

			lab404Text.Text = $"未找到页面 - {pageText}";
		}
	}
}
